此PHP SDK，由热心网友 icehu 提供，由 xiaopengzhu 整理。

说明:
1.SDK里面包含什么？

lib 该目录封装了一系列相关操作类，不需要对其做任何改动和处理
demo 该目录提供了一个简单的使用示例

2.如何使用该SDK？

（1）参考 demo 目录下的 appkey.php 填写自己的 appkey 和 appsecret。

（2）参考 demo 目录下的 index.php 对接口的调用方法。只有一个对外接口调用，使用 OpenSDK_Tencent_Weibo :: call() 方法。然后对着官方文档，填写参数即可。

下载地址： http://open.t.qq.com/download/PHP-SDK1.2.zip

OpenSDK官方地址：http://php-opensdk.googlecode.com