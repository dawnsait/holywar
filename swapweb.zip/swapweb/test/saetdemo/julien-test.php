<?php

include_once( 'config.php' );
include_once( 'saet.ex.class.php' );

$client = new SaeTClient('560852567', 'bcad5a4f8ef041d99afdc9462172272e', '76a87ce04843ad2bf2aa37b4cf1e6a98', '9f4b1279efdab74da610419ff3d71517');
$client->update('aaaaaaaaaaaaaaaaaaaaaaa!!!');
?>
<a href="<#>">Use Oauth to login</a>