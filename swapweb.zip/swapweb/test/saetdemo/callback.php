<?php

session_start();
include_once( 'config.php' );
include_once( 'saet.ex.class.php' );
header( "Content-Type:text/html;charset=UTF-8 ");

//$keys = array("oauth_token"=>"af893d033eb6fabb0ab4e6c11d6eb626","oauth_token_secret"=>"fd74defa330505dfed9d595e25e29345"); 
//$_SESSION['keys'] = $keys;
//print_r($_SESSION);

$o = new SaeTOAuth( WB_AKEY , WB_SKEY , $_SESSION['keys']['oauth_token'] , $_SESSION['keys']['oauth_token_secret']  );

$last_key = $o->getAccessToken(  $_REQUEST['oauth_verifier'] ) ;

$_SESSION['last_key'] = $last_key;

print_r($last_key);
?>
completed, <a href="weibolist.php">enter into your weibo!!!!!!!!</a>
