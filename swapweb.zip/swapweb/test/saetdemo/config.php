<?php
define( "WB_AKEY" , '560852567' );
define( "WB_SKEY" , 'bcad5a4f8ef041d99afdc9462172272e' );
define( "CALLBACK_URL", 'http://localhost/swapweb/test/saetdemo/callback.php');
?>